using Microsoft.AspNetCore.Mvc;

namespace Perfumy.Controllers
{
    public class MyPerfumeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        // GET: MyPerfumeController
        public ActionResult GetAll()
        {
            return View();
        }

    }
}
