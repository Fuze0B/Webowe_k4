using System;

namespace cw3_layout.Models;

public class CarsRepo
{
    public List<Perfume> Cars = new List<Perfume>
    {
        new Perfume{ Brand="Armani", Model="Emporio Stronger With You Intensely", Scent="Waniliowy pieprz",Amount=100},
        new Perfume{ Brand="Jean Paul Gaultier", Model="Le Male Le Parfum", Scent="Lawendowy",Amount=75},
        new Perfume{ Brand="Yves Saint Laurent", Model="Y",  Scent="Waniliowy pieprz",Amount=100},
    };

}