using System;

namespace cw3_layout.Models;

public class Perfume
{
    public string? Brand { get; set; } // marka
    public string? Model { get; set; } // nazwa
    public string? Scent { get; set; } // np waniliowy czy kichuj
    public int Amount { get; set; } // mililitry litry itd
}