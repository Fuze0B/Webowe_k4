using System;
namespace Perfumy.Models;

public class FakePerfumesRepo : IPerfumesRepo
{
    public List<Perfume> _Perfumes = new List<Perfume>
    {
        new Perfume{ Brand="Armani", Model="Emporio Stronger With You Intensely", Scent="Waniliowy pieprz",Amount=100},
        new Perfume{ Brand="Jean Paul Gaultier", Model="Le Male Le Parfum", Scent="Lawendowy",Amount=75},
        new Perfume{ Brand="Yves Saint Laurent", Model="Y",  Scent="Waniliowy pieprz",Amount=100},
    };

    public FakePerfumesRepo()
    {
        _Perfumes = _Perfumes;
    }
    public List<Perfume> Perfumes { get; set; }

    public void AddPerfume(Perfume perfume)
    {
        throw new NotImplementedException();
    }

    public List<Perfume> GetAllPerfumes()
    {
        return Perfumes;
    }

    public Perfume? GetPerfume(int id)
    {
        return Perfumes.FirstOrDefault(c => c.Id == id);
    }

    public void RemovePerfume(int id)
    {
        throw new NotImplementedException();
    }

    public void UpdatePerfume(Perfume perfume)
    {
        throw new NotImplementedException();
    }
}